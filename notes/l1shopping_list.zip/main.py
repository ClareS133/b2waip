print('Hello, world!')
shoppinglist1=["6 apples", "milk", "bread", "12 eggs"] #variable name and assign value using brackets
print("How many items on the shopping list?")
print(len(shoppinglist1)) #print how many items are on the list
shoppinglist1.sort() #sort the list into alphabetical order
print(shoppinglist1) #output what the variable holds
#run your program here to see the results
shoppinglist2=["cake", "biscuits", "chocolate"] #variable name and assign value using brackets
shoppinglist2.sort(reverse=True)#reverse order list items, remember True needs to start with a capital letter
for x in shoppinglist2: #output all items on by one until no more
  print(x)
#run your program here to see the results
fulllist=shoppinglist1 + shoppinglist2 #use + operator to join lists together and store in new variable
print(fulllist)
#run your program here to see the results
#CHALLENGE can you sort list alphabetically, list items one by one and print how many items are in the list?
