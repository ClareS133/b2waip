print('Hello, world!')
password='password'
p=input ('please enter a number\n')
if (p!=password):
  print ('You have entered an incorrect password')
else: 
  print ('You have successfully signed in')