# This program will demonstrate how we can create variables, use data types and obtain inputs
#declare variables and assign values
fullname="Joe Bloggs" #string
age=25 #integer
heightincm=152.4 #float
homeowner=True #boolean, True or False must start with uppercase

print(fullname) #add a print statement to output of each variable
print(age)
print(heightincm)
print(homeowner)

print("My name is " + fullname) #CHALLENGE output the rest of the data in this format

pet=input("Do you own a pet?") #take an input from the user to make our programs interactive
print(pet) #output user response
#CHALLENGE can you add more questions?